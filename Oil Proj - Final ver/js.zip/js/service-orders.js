/**
 * Service Orders Module
 * Handles all service order related operations including CRUD operations,
 * status management, scheduling, and cost calculations
 */

class ServiceOrdersModule {
    constructor() {
        this.orders = [];
        this.nextOrderId = 1;
        this.orderStatuses = {
            PENDING: 'pending',
            CONFIRMED: 'confirmed',
            IN_PROGRESS: 'in_progress',
            COMPLETED: 'completed',
            CANCELLED: 'cancelled'
        };
        this.serviceTypes = {
            CLEANING: 'cleaning',
            PLUMBING: 'plumbing',
            ELECTRICAL: 'electrical',
            MAINTENANCE: 'maintenance',
            REPAIR: 'repair',
            INSTALLATION: 'installation'
        };
        this.init();
    }

    /**
     * Initialize the module
     */
    init() {
        this.loadOrders();
        this.setupEventListeners();
        console.log('Service Orders Module initialized');
    }

    /**
     * Create a new service order
     * @param {Object} orderData - Order information
     * @returns {Object} Created order
     */
    createOrder(orderData) {
        try {
            const order = {
                id: this.nextOrderId++,
                customerId: orderData.customerId,
                customerName: orderData.customerName,
                customerEmail: orderData.customerEmail,
                customerPhone: orderData.customerPhone,
                serviceType: orderData.serviceType,
                description: orderData.description,
                address: orderData.address,
                scheduledDate: orderData.scheduledDate,
                scheduledTime: orderData.scheduledTime,
                estimatedDuration: orderData.estimatedDuration || 60, // minutes
                cost: orderData.cost || 0,
                status: this.orderStatuses.PENDING,
                providerId: orderData.providerId || null,
                providerName: orderData.providerName || null,
                notes: orderData.notes || '',
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
                completedAt: null,
                rating: null,
                feedback: null
            };

            this.orders.push(order);
            this.saveOrders();
            this.notifyOrderCreated(order);
            
            return {
                success: true,
                order: order,
                message: 'Service order created successfully'
            };
        } catch (error) {
            console.error('Error creating order:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Get all orders with optional filtering
     * @param {Object} filters - Filter criteria
     * @returns {Array} Filtered orders
     */
    getOrders(filters = {}) {
        let filteredOrders = [...this.orders];

        if (filters.status) {
            filteredOrders = filteredOrders.filter(order => order.status === filters.status);
        }

        if (filters.customerId) {
            filteredOrders = filteredOrders.filter(order => order.customerId === filters.customerId);
        }

        if (filters.providerId) {
            filteredOrders = filteredOrders.filter(order => order.providerId === filters.providerId);
        }

        if (filters.serviceType) {
            filteredOrders = filteredOrders.filter(order => order.serviceType === filters.serviceType);
        }

        if (filters.dateFrom) {
            filteredOrders = filteredOrders.filter(order => 
                new Date(order.scheduledDate) >= new Date(filters.dateFrom)
            );
        }

        if (filters.dateTo) {
            filteredOrders = filteredOrders.filter(order => 
                new Date(order.scheduledDate) <= new Date(filters.dateTo)
            );
        }

        return filteredOrders.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    }

    /**
     * Get a specific order by ID
     * @param {number} orderId - Order ID
     * @returns {Object|null} Order object or null if not found
     */
    getOrderById(orderId) {
        return this.orders.find(order => order.id === parseInt(orderId)) || null;
    }

    /**
     * Update an existing order
     * @param {number} orderId - Order ID
     * @param {Object} updateData - Data to update
     * @returns {Object} Update result
     */
    updateOrder(orderId, updateData) {
        try {
            const orderIndex = this.orders.findIndex(order => order.id === parseInt(orderId));
            
            if (orderIndex === -1) {
                return {
                    success: false,
                    error: 'Order not found'
                };
            }

            const order = this.orders[orderIndex];
            const updatedOrder = {
                ...order,
                ...updateData,
                updatedAt: new Date().toISOString()
            };

            // Handle status-specific updates
            if (updateData.status === this.orderStatuses.COMPLETED) {
                updatedOrder.completedAt = new Date().toISOString();
            }

            this.orders[orderIndex] = updatedOrder;
            this.saveOrders();
            this.notifyOrderUpdated(updatedOrder, order);

            return {
                success: true,
                order: updatedOrder,
                message: 'Order updated successfully'
            };
        } catch (error) {
            console.error('Error updating order:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Cancel an order
     * @param {number} orderId - Order ID
     * @param {string} reason - Cancellation reason
     * @returns {Object} Cancellation result
     */
    cancelOrder(orderId, reason = '') {
        const result = this.updateOrder(orderId, {
            status: this.orderStatuses.CANCELLED,
            notes: `${this.getOrderById(orderId)?.notes || ''}\nCancelled: ${reason}`.trim()
        });

        if (result.success) {
            result.message = 'Order cancelled successfully';
            this.notifyOrderCancelled(result.order, reason);
        }

        return result;
    }

    /**
     * Assign a service provider to an order
     * @param {number} orderId - Order ID
     * @param {number} providerId - Provider ID
     * @param {string} providerName - Provider name
     * @returns {Object} Assignment result
     */
    assignProvider(orderId, providerId, providerName) {
        const result = this.updateOrder(orderId, {
            providerId: providerId,
            providerName: providerName,
            status: this.orderStatuses.CONFIRMED
        });

        if (result.success) {
            result.message = 'Service provider assigned successfully';
            this.notifyProviderAssigned(result.order);
        }

        return result;
    }

    /**
     * Complete an order with rating and feedback
     * @param {number} orderId - Order ID
     * @param {number} rating - Rating (1-5)
     * @param {string} feedback - Customer feedback
     * @returns {Object} Completion result
     */
    completeOrder(orderId, rating = null, feedback = '') {
        const result = this.updateOrder(orderId, {
            status: this.orderStatuses.COMPLETED,
            rating: rating,
            feedback: feedback
        });

        if (result.success) {
            result.message = 'Order completed successfully';
            this.notifyOrderCompleted(result.order);
        }

        return result;
    }

    /**
     * Get orders statistics
     * @returns {Object} Statistics object
     */
    getOrdersStats() {
        const stats = {
            total: this.orders.length,
            pending: 0,
            confirmed: 0,
            inProgress: 0,
            completed: 0,
            cancelled: 0,
            totalRevenue: 0,
            averageRating: 0,
            serviceTypeBreakdown: {}
        };

        let totalRating = 0;
        let ratedOrders = 0;

        this.orders.forEach(order => {
            // Status counts
            stats[order.status.replace('_', '')]++;

            // Revenue calculation
            if (order.status === this.orderStatuses.COMPLETED) {
                stats.totalRevenue += order.cost;
            }

            // Rating calculation
            if (order.rating) {
                totalRating += order.rating;
                ratedOrders++;
            }

            // Service type breakdown
            if (!stats.serviceTypeBreakdown[order.serviceType]) {
                stats.serviceTypeBreakdown[order.serviceType] = 0;
            }
            stats.serviceTypeBreakdown[order.serviceType]++;
        });

        stats.averageRating = ratedOrders > 0 ? (totalRating / ratedOrders).toFixed(1) : 0;

        return stats;
    }

    /**
     * Get upcoming orders (next 7 days)
     * @returns {Array} Upcoming orders
     */
    getUpcomingOrders() {
        const today = new Date();
        const nextWeek = new Date(today.getTime() + 7 * 24 * 60 * 60 * 1000);

        return this.orders.filter(order => {
            const orderDate = new Date(order.scheduledDate);
            return orderDate >= today && orderDate <= nextWeek && 
                   order.status !== this.orderStatuses.CANCELLED;
        }).sort((a, b) => new Date(a.scheduledDate) - new Date(b.scheduledDate));
    }

    /**
     * Search orders by multiple criteria
     * @param {string} searchTerm - Search term
     * @returns {Array} Matching orders
     */
    searchOrders(searchTerm) {
        const term = searchTerm.toLowerCase();
        
        return this.orders.filter(order => 
            order.customerName.toLowerCase().includes(term) ||
            order.customerEmail.toLowerCase().includes(term) ||
            order.description.toLowerCase().includes(term) ||
            order.address.toLowerCase().includes(term) ||
            order.serviceType.toLowerCase().includes(term) ||
            order.id.toString().includes(term)
        );
    }

    /**
     * Validate order data
     * @param {Object} orderData - Order data to validate
     * @returns {Object} Validation result
     */
    validateOrder(orderData) {
        const errors = [];

        if (!orderData.customerName || orderData.customerName.trim().length < 2) {
            errors.push('Customer name is required and must be at least 2 characters');
        }

        if (!orderData.customerEmail || !this.isValidEmail(orderData.customerEmail)) {
            errors.push('Valid customer email is required');
        }

        if (!orderData.customerPhone || orderData.customerPhone.trim().length < 10) {
            errors.push('Valid customer phone number is required');
        }

        if (!orderData.serviceType || !Object.values(this.serviceTypes).includes(orderData.serviceType)) {
            errors.push('Valid service type is required');
        }

        if (!orderData.description || orderData.description.trim().length < 10) {
            errors.push('Service description must be at least 10 characters');
        }

        if (!orderData.address || orderData.address.trim().length < 5) {
            errors.push('Service address is required');
        }

        if (!orderData.scheduledDate) {
            errors.push('Scheduled date is required');
        } else {
            const scheduledDate = new Date(orderData.scheduledDate);
            const today = new Date();
            today.setHours(0, 0, 0, 0);
            
            if (scheduledDate < today) {
                errors.push('Scheduled date cannot be in the past');
            }
        }

        if (!orderData.scheduledTime) {
            errors.push('Scheduled time is required');
        }

        if (orderData.cost && (isNaN(orderData.cost) || orderData.cost < 0)) {
            errors.push('Cost must be a valid positive number');
        }

        return {
            isValid: errors.length === 0,
            errors: errors
        };
    }

    /**
     * Calculate estimated cost based on service type and duration
     * @param {string} serviceType - Type of service
     * @param {number} duration - Duration in minutes
     * @returns {number} Estimated cost
     */
    calculateEstimatedCost(serviceType, duration) {
        const baseCosts = {
            [this.serviceTypes.CLEANING]: 30, // per hour
            [this.serviceTypes.PLUMBING]: 80,
            [this.serviceTypes.ELECTRICAL]: 90,
            [this.serviceTypes.MAINTENANCE]: 50,
            [this.serviceTypes.REPAIR]: 60,
            [this.serviceTypes.INSTALLATION]: 75
        };

        const hourlyRate = baseCosts[serviceType] || 50;
        const hours = duration / 60;
        return Math.round(hourlyRate * hours);
    }

    /**
     * Get available time slots for a given date
     * @param {string} date - Date in YYYY-MM-DD format
     * @param {number} providerId - Optional provider ID
     * @returns {Array} Available time slots
     */
    getAvailableTimeSlots(date, providerId = null) {
        const bookedSlots = this.orders
            .filter(order => 
                order.scheduledDate === date && 
                order.status !== this.orderStatuses.CANCELLED &&
                (!providerId || order.providerId === providerId)
            )
            .map(order => order.scheduledTime);

        const allSlots = [];
        for (let hour = 8; hour <= 18; hour++) {
            for (let minute = 0; minute < 60; minute += 30) {
                const timeSlot = `${hour.toString().padStart(2, '0')}:${minute.toString().padStart(2, '0')}`;
                if (!bookedSlots.includes(timeSlot)) {
                    allSlots.push(timeSlot);
                }
            }
        }

        return allSlots;
    }

    /**
     * Export orders data
     * @param {string} format - Export format ('json' or 'csv')
     * @param {Object} filters - Optional filters
     * @returns {string} Exported data
     */
    exportOrders(format = 'json', filters = {}) {
        const ordersToExport = this.getOrders(filters);

        if (format === 'csv') {
            const headers = [
                'ID', 'Customer Name', 'Email', 'Phone', 'Service Type',
                'Description', 'Address', 'Scheduled Date', 'Scheduled Time',
                'Status', 'Provider', 'Cost', 'Rating', 'Created At'
            ];

            const csvRows = ordersToExport.map(order => [
                order.id,
                order.customerName,
                order.customerEmail,
                order.customerPhone,
                order.serviceType,
                order.description.replace(/,/g, ';'), // Replace commas to avoid CSV issues
                order.address.replace(/,/g, ';'),
                order.scheduledDate,
                order.scheduledTime,
                order.status,
                order.providerName || 'Not assigned',
                order.cost,
                order.rating || 'Not rated',
                order.createdAt
            ]);

            return [headers, ...csvRows]
                .map(row => row.map(field => `"${field}"`).join(','))
                .join('\n');
        }

        return JSON.stringify(ordersToExport, null, 2);
    }

    /**
     * Import orders from JSON data
     * @param {string} jsonData - JSON string containing orders
     * @returns {Object} Import result
     */
    importOrders(jsonData) {
        try {
            const importedOrders = JSON.parse(jsonData);
            let successCount = 0;
            let errorCount = 0;
            const errors = [];

            importedOrders.forEach((orderData, index) => {
                const validation = this.validateOrder(orderData);
                if (validation.isValid) {
                    this.createOrder(orderData);
                    successCount++;
                } else {
                    errorCount++;
                    errors.push(`Row ${index + 1}: ${validation.errors.join(', ')}`);
                }
            });

            return {
                success: errorCount === 0,
                successCount: successCount,
                errorCount: errorCount,
                errors: errors,
                message: `Import completed: ${successCount} successful, ${errorCount} failed`
            };
        } catch (error) {
            console.error('Error importing orders:', error);
            return {
                success: false,
                error: 'Invalid JSON data or import failed'
            };
        }
    }

    /**
     * Get orders requiring equipment
     * @returns {Array} Orders that need equipment assignment
     */
    getOrdersRequiringEquipment() {
        return this.orders.filter(order => 
            (order.serviceType === this.serviceTypes.MAINTENANCE || 
             order.serviceType === this.serviceTypes.REPAIR ||
             order.serviceType === this.serviceTypes.INSTALLATION) &&
            order.status !== this.orderStatuses.CANCELLED &&
            order.status !== this.orderStatuses.COMPLETED
        );
    }

    /**
     * Assign equipment to a service order
     * @param {number} orderId - Order ID
     * @param {Array} equipmentItems - Array of equipment items
     * @returns {Object} Assignment result
     */
    assignEquipment(orderId, equipmentItems) {
        try {
            const order = this.getOrderById(orderId);
            if (!order) {
                return {
                    success: false,
                    error: 'Order not found'
                };
            }

            // Validate equipment availability
            const equipmentValidation = this.validateEquipmentAvailability(equipmentItems);
            if (!equipmentValidation.isValid) {
                return {
                    success: false,
                    error: equipmentValidation.error
                };
            }

            const result = this.updateOrder(orderId, {
                assignedEquipment: equipmentItems,
                equipmentAssignedAt: new Date().toISOString()
            });

            if (result.success) {
                // Update equipment status to "In Use"
                this.updateEquipmentStatus(equipmentItems, 'in_use');
                result.message = 'Equipment assigned successfully';
                this.notifyEquipmentAssigned(result.order, equipmentItems);
            }

            return result;
        } catch (error) {
            console.error('Error assigning equipment:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Release equipment from completed/cancelled orders
     * @param {number} orderId - Order ID
     * @returns {Object} Release result
     */
    releaseEquipment(orderId) {
        try {
            const order = this.getOrderById(orderId);
            if (!order || !order.assignedEquipment) {
                return {
                    success: false,
                    error: 'Order not found or no equipment assigned'
                };
            }

            // Update equipment status back to available
            this.updateEquipmentStatus(order.assignedEquipment, 'ready');

            const result = this.updateOrder(orderId, {
                assignedEquipment: null,
                equipmentReleasedAt: new Date().toISOString()
            });

            if (result.success) {
                result.message = 'Equipment released successfully';
                this.notifyEquipmentReleased(result.order);
            }

            return result;
        } catch (error) {
            console.error('Error releasing equipment:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    /**
     * Create equipment maintenance order
     * @param {Object} equipmentData - Equipment information
     * @param {string} issueDescription - Description of the issue
     * @returns {Object} Created maintenance order
     */
    createEquipmentMaintenanceOrder(equipmentData, issueDescription) {
        const maintenanceOrderData = {
            customerId: 'INTERNAL',
            customerName: 'Internal Maintenance',
            customerEmail: 'maintenance@company.com',
            customerPhone: '000-000-0000',
            serviceType: this.serviceTypes.MAINTENANCE,
            description: `Equipment Maintenance: ${equipmentData.name} (SKU: ${equipmentData.sku}) - ${issueDescription}`,
            address: 'Equipment Storage/Workshop',
            scheduledDate: new Date().toISOString().split('T')[0],
            scheduledTime: '09:00',
            estimatedDuration: 120,
            cost: this.calculateMaintenanceCost(equipmentData.type),
            equipmentId: equipmentData.id,
            equipmentSku: equipmentData.sku,
            priority: this.getMaintenancePriority(issueDescription)
        };

        return this.createOrder(maintenanceOrderData);
    }

    /**
     * Get maintenance schedule for equipment
     * @param {string} period - Period ('week', 'month', 'quarter')
     * @returns {Array} Scheduled maintenance orders
     */
    getMaintenanceSchedule(period = 'month') {
        const now = new Date();
        let endDate = new Date();

        switch (period) {
            case 'week':
                endDate.setDate(now.getDate() + 7);
                break;
            case 'month':
                endDate.setMonth(now.getMonth() + 1);
                break;
            case 'quarter':
                endDate.setMonth(now.getMonth() + 3);
                break;
        }

        return this.orders.filter(order => 
            order.serviceType === this.serviceTypes.MAINTENANCE &&
            order.customerId === 'INTERNAL' &&
            new Date(order.scheduledDate) >= now &&
            new Date(order.scheduledDate) <= endDate
        ).sort((a, b) => new Date(a.scheduledDate) - new Date(b.scheduledDate));
    }

    /**
     * Generate service order report
     * @param {string} reportType - Type of report
     * @param {Object} parameters - Report parameters
     * @returns {Object} Report data
     */
    generateReport(reportType, parameters = {}) {
        const reports = {
            daily: () => this.getDailyReport(parameters.date),
            weekly: () => this.getWeeklyReport(parameters.startDate),
            monthly: () => this.getMonthlyReport(parameters.month, parameters.year),
            equipment_utilization: () => this.getEquipmentUtilizationReport(parameters.period),
            provider_performance: () => this.getProviderPerformanceReport(parameters.providerId),
            customer_history: () => this.getCustomerHistoryReport(parameters.customerId)
        };

        const reportGenerator = reports[reportType];
        if (!reportGenerator) {
            return {
                success: false,
                error: 'Invalid report type'
            };
        }

        try {
            const reportData = reportGenerator();
            return {
                success: true,
                reportType: reportType,
                generatedAt: new Date().toISOString(),
                data: reportData
            };
        } catch (error) {
            console.error('Error generating report:', error);
            return {
                success: false,
                error: error.message
            };
        }
    }

    // Helper Methods

    /**
     * Validate equipment availability
     * @param {Array} equipmentItems - Equipment items to validate
     * @returns {Object} Validation result
     */
    validateEquipmentAvailability(equipmentItems) {
        // This would integrate with equipment management system
        // For now, assume all equipment is available
        return {
            isValid: true,
            unavailableItems: []
        };
    }

    /**
     * Update equipment status
     * @param {Array} equipmentItems - Equipment items
     * @param {string} status - New status
     */
    updateEquipmentStatus(equipmentItems, status) {
        // This would integrate with equipment management system
        console.log(`Updating equipment status to ${status}:`, equipmentItems);
        
        // Dispatch event for equipment module to handle
        this.dispatchEvent('equipmentStatusUpdate', {
            equipmentItems: equipmentItems,
            status: status,
            timestamp: new Date().toISOString()
        });
    }

    /**
     * Calculate maintenance cost based on equipment type
     * @param {string} equipmentType - Type of equipment
     * @returns {number} Estimated maintenance cost
     */
    calculateMaintenanceCost(equipmentType) {
        const maintenanceCosts = {
            'rotary_hand_sifter': 150,
            'slip_body': 80,
            'slip_segments': 40,
            'insert_teeth': 60,
            'handles': 25
        };

        return maintenanceCosts[equipmentType] || 100;
    }

    /**
     * Get maintenance priority based on issue description
     * @param {string} issueDescription - Description of the issue
     * @returns {string} Priority level
     */
    getMaintenancePriority(issueDescription) {
        const urgent = ['broken', 'damaged', 'safety', 'critical', 'emergency'];
        const high = ['wear', 'performance', 'efficiency', 'malfunction'];
        
        const desc = issueDescription.toLowerCase();
        
        if (urgent.some(keyword => desc.includes(keyword))) {
            return 'urgent';
        } else if (high.some(keyword => desc.includes(keyword))) {
            return 'high';
        }
        
        return 'medium';
    }

    /**
     * Get daily report
     * @param {string} date - Date in YYYY-MM-DD format
     * @returns {Object} Daily report data
     */
    getDailyReport(date) {
        const dayOrders = this.orders.filter(order => order.scheduledDate === date);
        
        return {
            date: date,
            totalOrders: dayOrders.length,
            completedOrders: dayOrders.filter(o => o.status === this.orderStatuses.COMPLETED).length,
            pendingOrders: dayOrders.filter(o => o.status === this.orderStatuses.PENDING).length,
            revenue: dayOrders
                .filter(o => o.status === this.orderStatuses.COMPLETED)
                .reduce((sum, o) => sum + o.cost, 0),
            orders: dayOrders
        };
    }

    /**
     * Get equipment utilization report
     * @param {string} period - Report period
     * @returns {Object} Equipment utilization data
     */
    getEquipmentUtilizationReport(period = 'month') {
        const ordersWithEquipment = this.orders.filter(order => order.assignedEquipment);
        
        // Group by equipment and calculate usage statistics
        const equipmentUsage = {};
        
        ordersWithEquipment.forEach(order => {
            if (order.assignedEquipment) {
                order.assignedEquipment.forEach(equipment => {
                    if (!equipmentUsage[equipment.sku]) {
                        equipmentUsage[equipment.sku] = {
                            sku: equipment.sku,
                            name: equipment.name,
                            totalUsage: 0,
                            totalOrders: 0,
                            totalDuration: 0
                        };
                    }
                    
                    equipmentUsage[equipment.sku].totalUsage++;
                    equipmentUsage[equipment.sku].totalOrders++;
                    equipmentUsage[equipment.sku].totalDuration += order.estimatedDuration || 60;
                });
            }
        });

        return {
            period: period,
            equipmentUsage: Object.values(equipmentUsage),
            totalEquipmentOrders: ordersWithEquipment.length
        };
    }

    /**
     * Validate email format
     * @param {string} email - Email to validate
     * @returns {boolean} Is valid email
     */
    isValidEmail(email) {
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return emailRegex.test(email);
    }

    /**
     * Load orders from storage
     */
    loadOrders() {
        // In a real application, this would load from a database
        // For demo purposes, we'll initialize with some sample data
        if (this.orders.length === 0) {
            this.initializeSampleData();
        }
    }

    /**
     * Save orders to storage
     */
    saveOrders() {
        // In a real application, this would save to a database
        console.log('Orders saved:', this.orders.length, 'orders');
    }

    /**
     * Initialize with sample data
     */
    initializeSampleData() {
        const sampleOrders = [
            {
                id: this.nextOrderId++,
                customerId: 'CUST001',
                customerName: 'ABC Manufacturing',
                customerEmail: 'contact@abcmanufacturing.com',
                customerPhone: '+1-555-0123',
                serviceType: this.serviceTypes.MAINTENANCE,
                description: 'Rotary hand sifter maintenance and calibration',
                address: '123 Industrial Ave, Manufacturing District',
                scheduledDate: '2025-09-05',
                scheduledTime: '10:00',
                estimatedDuration: 120,
                cost: 150,
                status: this.orderStatuses.CONFIRMED,
                providerId: 'PROV001',
                providerName: 'Expert Maintenance Co.',
                assignedEquipment: [
                    { sku: '10000', name: '9 5/8" Rotary hand sifter', quantity: 1 }
                ],
                notes: 'Customer reports efficiency issues',
                createdAt: '2025-09-01T08:00:00.000Z',
                updatedAt: '2025-09-01T09:00:00.000Z'
            }
        ];

        this.orders = sampleOrders;
        this.nextOrderId = sampleOrders.length + 1;
    }

    /**
     * Setup event listeners for UI interactions
     */
    setupEventListeners() {
        // Listen for equipment status changes
        document.addEventListener('equipmentStatusChanged', (event) => {
            this.handleEquipmentStatusChange(event.detail);
        });

        // Listen for order form submissions
        document.addEventListener('serviceOrderSubmit', (event) => {
            this.handleOrderSubmission(event.detail);
        });
    }

    /**
     * Handle equipment status changes
     * @param {Object} eventData - Equipment status change data
     */
    handleEquipmentStatusChange(eventData) {
        const { equipmentSku, oldStatus, newStatus } = eventData;
        
        // If equipment becomes unavailable, check for affected orders
        if (newStatus === 'damage' || newStatus === 'under_inspection') {
            const affectedOrders = this.orders.filter(order => 
                order.assignedEquipment &&
                order.assignedEquipment.some(eq => eq.sku === equipmentSku) &&
                order.status !== this.orderStatuses.COMPLETED &&
                order.status !== this.orderStatuses.CANCELLED
            );

            affectedOrders.forEach(order => {
                this.notifyEquipmentUnavailable(order, equipmentSku);
            });
        }
    }

    /**
     * Handle order form submission
     * @param {Object} formData - Form data
     */
    handleOrderSubmission(formData) {
        const validation = this.validateOrder(formData);
        
        if (validation.isValid) {
            const result = this.createOrder(formData);
            this.displayOrderResult(result);
        } else {
            this.displayValidationErrors(validation.errors);
        }
    }

    // Notification Methods

    /**
     * Notify when order is created
     * @param {Object} order - Created order
     */
    notifyOrderCreated(order) {
        this.dispatchEvent('orderCreated', order);
        console.log(`Order ${order.id} created for ${order.customerName}`);
    }

    /**
     * Notify when order is updated
     * @param {Object} newOrder - Updated order
     * @param {Object} oldOrder - Previous order state
     */
    notifyOrderUpdated(newOrder, oldOrder) {
        this.dispatchEvent('orderUpdated', { newOrder, oldOrder });
        console.log(`Order ${newOrder.id} updated - Status: ${newOrder.status}`);
    }

    /**
     * Notify when order is cancelled
     * @param {Object} order - Cancelled order
     * @param {string} reason - Cancellation reason
     */
    notifyOrderCancelled(order, reason) {
        this.dispatchEvent('orderCancelled', { order, reason });
        console.log(`Order ${order.id} cancelled: ${reason}`);
    }

    /**
     * Notify when provider is assigned
     * @param {Object} order - Order with assigned provider
     */
    notifyProviderAssigned(order) {
        this.dispatchEvent('providerAssigned', order);
        console.log(`Provider ${order.providerName} assigned to order ${order.id}`);
    }

    /**
     * Notify when order is completed
     * @param {Object} order - Completed order
     */
    notifyOrderCompleted(order) {
        this.dispatchEvent('orderCompleted', order);
        console.log(`Order ${order.id} completed with rating: ${order.rating || 'No rating'}`);
    }

    /**
     * Notify when equipment is assigned
     * @param {Object} order - Order
     * @param {Array} equipmentItems - Assigned equipment
     */
    notifyEquipmentAssigned(order, equipmentItems) {
        this.dispatchEvent('equipmentAssigned', { order, equipmentItems });
        console.log(`Equipment assigned to order ${order.id}:`, equipmentItems);
    }

    /**
     * Notify when equipment is released
     * @param {Object} order - Order
     */
    notifyEquipmentReleased(order) {
        this.dispatchEvent('equipmentReleased', order);
        console.log(`Equipment released from order ${order.id}`);
    }

    /**
     * Notify when equipment becomes unavailable
     * @param {Object} order - Affected order
     * @param {string} equipmentSku - Equipment SKU
     */
    notifyEquipmentUnavailable(order, equipmentSku) {
        this.dispatchEvent('equipmentUnavailable', { order, equipmentSku });
        console.log(`Equipment ${equipmentSku} unavailable for order ${order.id}`);
    }

    /**
     * Dispatch custom events
     * @param {string} eventType - Event type
     * @param {Object} eventData - Event data
     */
    dispatchEvent(eventType, eventData) {
        const event = new CustomEvent(eventType, {
            detail: eventData,
            bubbles: true
        });
        document.dispatchEvent(event);
    }

    /**
     * Display order creation/update result
     * @param {Object} result - Operation result
     */
    displayOrderResult(result) {
        if (result.success) {
            this.showSuccessMessage(result.message);
            this.refreshOrderList();
        } else {
            this.showErrorMessage(result.error);
        }
    }

    /**
     * Display validation errors
     * @param {Array} errors - Validation errors
     */
    displayValidationErrors(errors) {
        const errorMessage = 'Please fix the following errors:\n' + errors.join('\n');
        this.showErrorMessage(errorMessage);
    }

    /**
     * Show success message
     * @param {string} message - Success message
     */
    showSuccessMessage(message) {
        // Integrate with your notification system
        console.log('Success:', message);
        
        // You can integrate with a toast notification system here
        this.dispatchEvent('showNotification', {
            type: 'success',
            message: message
        });
    }

    /**
     * Show error message
     * @param {string} message - Error message
     */
    showErrorMessage(message) {
        // Integrate with your notification system
        console.error('Error:', message);
        
        // You can integrate with a toast notification system here
        this.dispatchEvent('showNotification', {
            type: 'error',
            message: message
        });
    }

    /**
     * Refresh order list in UI
     */
    refreshOrderList() {
        this.dispatchEvent('refreshOrderList', {
            orders: this.getOrders()
        });
    }

    /**
     * Get provider performance report
     * @param {number} providerId - Provider ID
     * @returns {Object} Performance data
     */
    getProviderPerformanceReport(providerId) {
        const providerOrders = this.orders.filter(order => 
            order.providerId === providerId && 
            order.status === this.orderStatuses.COMPLETED
        );

        const totalOrders = providerOrders.length;
        const averageRating = totalOrders > 0 ? 
            providerOrders.reduce((sum, order) => sum + (order.rating || 0), 0) / totalOrders : 0;
        
        const totalRevenue = providerOrders.reduce((sum, order) => sum + order.cost, 0);

        return {
            providerId: providerId,
            totalOrders: totalOrders,
            averageRating: averageRating.toFixed(1),
            totalRevenue: totalRevenue,
            completionRate: totalOrders > 0 ? 
                (providerOrders.length / this.orders.filter(o => o.providerId === providerId).length * 100).toFixed(1) : 0
        };
    }

    /**
     * Get customer history report
     * @param {string} customerId - Customer ID
     * @returns {Object} Customer history data
     */
    getCustomerHistoryReport(customerId) {
        const customerOrders = this.orders.filter(order => order.customerId === customerId);
        
        return {
            customerId: customerId,
            customerName: customerOrders[0]?.customerName || 'Unknown',
            totalOrders: customerOrders.length,
            completedOrders: customerOrders.filter(o => o.status === this.orderStatuses.COMPLETED).length,
            totalSpent: customerOrders
                .filter(o => o.status === this.orderStatuses.COMPLETED)
                .reduce((sum, order) => sum + order.cost, 0),
            averageOrderValue: customerOrders.length > 0 ?
                customerOrders.reduce((sum, order) => sum + order.cost, 0) / customerOrders.length : 0,
            preferredServices: this.getCustomerServicePreferences(customerOrders),
            lastOrderDate: customerOrders.length > 0 ?
                Math.max(...customerOrders.map(o => new Date(o.createdAt))) : null
        };
    }

    /**
     * Get customer service preferences
     * @param {Array} customerOrders - Customer orders
     * @returns {Array} Preferred service types
     */
    getCustomerServicePreferences(customerOrders) {
        const serviceCount = {};
        
        customerOrders.forEach(order => {
            serviceCount[order.serviceType] = (serviceCount[order.serviceType] || 0) + 1;
        });

        return Object.entries(serviceCount)
            .sort(([,a], [,b]) => b - a)
            .map(([service, count]) => ({ service, count }));
    }

    // Public API Methods for Integration

    /**
     * Get module status and health
     * @returns {Object} Module status
     */
    getModuleStatus() {
        return {
            initialized: true,
            totalOrders: this.orders.length,
            activeOrders: this.orders.filter(o => 
                o.status !== this.orderStatuses.COMPLETED && 
                o.status !== this.orderStatuses.CANCELLED
            ).length,
            lastActivity: this.orders.length > 0 ? 
                Math.max(...this.orders.map(o => new Date(o.updatedAt))) : null
        };
    }

    /**
     * Cleanup resources
     */
    destroy() {
        this.orders = [];
        document.removeEventListener('equipmentStatusChanged', this.handleEquipmentStatusChange);
        document.removeEventListener('serviceOrderSubmit', this.handleOrderSubmission);
        console.log('Service Orders Module destroyed');
    }
}

// Create and export singleton instance
const serviceOrdersModule = new ServiceOrdersModule();

// Export for module systems
if (typeof module !== 'undefined' && module.exports) {
    module.exports = serviceOrdersModule;
}

// Global access
window.ServiceOrders = serviceOrdersModule;