/**
 * Navigation Module
 * Handles page navigation, menu interactions, and route management
 * Updated to include Service Orders integration
 */

class Navigation {
    constructor() {
        this.currentPage = 'dashboard';
        this.pages = {
            dashboard: {
                title: 'Dashboard',
                icon: 'dashboard',
                file: 'dashboard.html',
                module: null
            },
            operations: {
                title: 'Operations',
                icon: 'operations',
                file: 'operations.html',
                module: 'OperationsModule'
            },
            'service-orders': {
                title: 'Service Orders',
                icon: 'service',
                file: 'service-orders.html',
                module: 'ServiceOrdersUI',
                submodules: ['ServiceOrders', 'EquipmentIntegration']
            },
            inventory: {
                title: 'Inventory',
                icon: 'inventory',
                file: 'inventory.html',
                module: 'InventoryModule'
            },
            equipment: {
                title: 'Equipment',
                icon: 'equipment',
                file: 'equipment.html',
                module: 'EquipmentModule'
            },
            providers: {
                title: 'Providers',
                icon: 'providers',
                file: 'providers.html',
                module: 'ProvidersModule'
            },
            customers: {
                title: 'Customers',
                icon: 'customers',
                file: 'customers.html',
                module: 'CustomersModule'
            },
            reports: {
                title: 'Reports',
                icon: 'reports',
                file: 'reports.html',
                module: 'ReportsModule'
            },
            settings: {
                title: 'Settings',
                icon: 'settings',
                file: 'settings.html',
                module: 'SettingsModule'
            }
        };
        this.breadcrumbs = [];
        this.badgeUpdateInterval = null;
        this.init();
    }

    /**
     * Initialize navigation
     */
    init() {
        this.createNavigationHTML();
        this.setupEventListeners();
        this.loadInitialPage();
        this.updateActiveMenuItem();
        console.log('Navigation initialized');
    }

    /**
     * Create navigation HTML structure
     */
    createNavigationHTML() {
        // Update sidebar navigation
        const sidebar = document.querySelector('.sidebar');
        if (sidebar) {
            const navMenu = sidebar.querySelector('.nav-menu') || sidebar;
            navMenu.innerHTML = `
                <div class="nav-header">
                    <div class="logo">
                        <span class="logo-text">Logistics</span>
                    </div>
                </div>
                <ul class="nav-list">
                    <li class="nav-item">
                        <a href="#" class="nav-link" data-page="dashboard">
                            <i class="nav-icon icon-dashboard">📊</i>
                            <span class="nav-text">Dashboard</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link" data-page="operations">
                            <i class="nav-icon icon-operations">⚙️</i>
                            <span class="nav-text">Operations</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link" data-page="service-orders">
                            <i class="nav-icon icon-service">🛠️</i>
                            <span class="nav-text">Service Orders</span>
                            <span class="nav-badge" id="serviceOrdersBadge" style="display: none;">0</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link" data-page="inventory">
                            <i class="nav-icon icon-inventory">📦</i>
                            <span class="nav-text">Inventory</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link" data-page="equipment">
                            <i class="nav-icon icon-equipment">🔧</i>
                            <span class="nav-text">Equipment</span>
                            <span class="nav-badge" id="equipmentBadge" style="display: none;">0</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link" data-page="providers">
                            <i class="nav-icon icon-providers">👥</i>
                            <span class="nav-text">Providers</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link" data-page="customers">
                            <i class="nav-icon icon-customers">👤</i>
                            <span class="nav-text">Customers</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link" data-page="reports">
                            <i class="nav-icon icon-reports">📈</i>
                            <span class="nav-text">Reports</span>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="#" class="nav-link" data-page="settings">
                            <i class="nav-icon icon-settings">⚙️</i>
                            <span class="nav-text">Settings</span>
                        </a>
                    </li>
                </ul>
                
                <!-- User Profile Section -->
                <div class="nav-footer">
                    <div class="user-profile">
                        <div class="user-avatar">
                            <img src="data:image/svg+xml,${encodeURIComponent('<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>')}" alt="User Avatar">
                        </div>
                        <div class="user-info">
                            <span class="user-name">Mustafa</span>
                            <span class="user-role">Admin</span>
                        </div>
                    </div>
                    <button class="logout-btn" id="logoutBtn">
                        <i class="icon-logout">🚪</i>
                    </button>
                </div>
            `;
        }

        // Create breadcrumb container if it doesn't exist
        if (!document.querySelector('.breadcrumb-container')) {
            const mainContent = document.getElementById('main-content');
            if (mainContent) {
                const breadcrumbContainer = document.createElement('div');
                breadcrumbContainer.className = 'breadcrumb-container';
                breadcrumbContainer.innerHTML = '<nav class="breadcrumb" id="breadcrumb"></nav>';
                mainContent.parentNode.insertBefore(breadcrumbContainer, mainContent);
            }
        }
    }

    /**
     * Setup navigation event listeners
     */
    setupEventListeners() {
        // Bind methods to maintain context
        this.handleNavigationClick = this.handleNavigationClick.bind(this);
        this.handlePopState = this.handlePopState.bind(this);

        // Navigation clicks
        document.addEventListener('click', this.handleNavigationClick);

        // Browser back/forward navigation
        window.addEventListener('popstate', this.handlePopState);

        // Service Orders events for badge updates
        document.addEventListener('orderCreated', () => {
            this.updateServiceOrdersBadge();
        });

        document.addEventListener('orderUpdated', () => {
            this.updateServiceOrdersBadge();
        });

        // Equipment events for badge updates
        document.addEventListener('equipmentStatusChanged', () => {
            this.updateEquipmentBadge();
        });

        document.addEventListener('maintenanceOrderCreated', () => {
            this.updateServiceOrdersBadge();
            this.updateEquipmentBadge();
        });

        // Module ready events
        document.addEventListener('DOMContentLoaded', () => {
            this.initializeModules();
        });
    }

    /**
     * Handle navigation clicks
     * @param {Event} e - Click event
     */
    handleNavigationClick(e) {
        if (e.target.classList.contains('nav-link') || e.target.closest('.nav-link')) {
            e.preventDefault();
            const link = e.target.classList.contains('nav-link') ? e.target : e.target.closest('.nav-link');
            const page = link.dataset.page;
            if (page) {
                this.navigateTo(page);
            }
        }

        // Logout
        if (e.target.id === 'logoutBtn' || e.target.closest('#logoutBtn')) {
            this.handleLogout();
        }

        // Breadcrumb navigation
        if (e.target.classList.contains('breadcrumb-link')) {
            e.preventDefault();
            const page = e.target.dataset.page;
            if (page) {
                this.navigateTo(page);
            }
        }

        // Dashboard quick actions
        if (e.target.closest('[data-action="create-order"]')) {
            this.navigateTo('service-orders');
            // Trigger add order modal after navigation
            setTimeout(() => {
                if (window.ServiceOrdersUI) {
                    window.ServiceOrdersUI.showAddOrderModal();
                }
            }, 100);
        } else if (e.target.closest('[data-action="equipment-status"]')) {
            this.navigateTo('equipment');
        } else if (e.target.closest('[data-action="maintenance-schedule"]')) {
            this.navigateTo('service-orders');
            // Filter for maintenance orders
            setTimeout(() => {
                const statusFilter = document.getElementById('statusFilter');
                const serviceTypeFilter = document.getElementById('serviceTypeFilter');
                if (statusFilter) statusFilter.value = 'confirmed';
                if (serviceTypeFilter) serviceTypeFilter.value = 'maintenance';
                if (window.ServiceOrdersUI) {
                    window.ServiceOrdersUI.applyFilters();
                }
            }, 100);
        } else if (e.target.closest('[data-action="reports"]')) {
            this.navigateTo('reports');
        }

        // Mobile menu clicks
        if (e.target.id === 'mobileMenuToggle') {
            const mobileMenu = document.getElementById('mobileMenu');
            if (mobileMenu) {
                mobileMenu.classList.add('active');
            }
        }

        if (e.target.id === 'closeMobileMenu') {
            const mobileMenu = document.getElementById('mobileMenu');
            if (mobileMenu) {
                mobileMenu.classList.remove('active');
            }
        }

        if (e.target.classList.contains('mobile-nav-link')) {
            e.preventDefault();
            const page = e.target.dataset.page;
            this.navigateTo(page);
            const mobileMenu = document.getElementById('mobileMenu');
            if (mobileMenu) {
                mobileMenu.classList.remove('active');
            }
        }
    }

    /**
     * Handle browser back/forward navigation
     * @param {Event} e - Popstate event
     */
    handlePopState(e) {
        if (e.state && e.state.page) {
            this.loadPage(e.state.page, false);
        }
    }

    /**
     * Navigate to a specific page
     * @param {string} page - Page to navigate to
     * @param {boolean} updateHistory - Whether to update browser history
     */
    navigateTo(page, updateHistory = true) {
        if (!this.pages[page]) {
            console.error('Page not found:', page);
            if (window.NotificationSystem) {
                window.NotificationSystem.showError(`Page "${page}" not found`);
            }
            return;
        }

        // Check if modules are ready for the page
        if (!this.checkModuleRequirements(page)) {
            if (window.NotificationSystem) {
                window.NotificationSystem.showWarning('Required modules are still loading...');
            }
            return;
        }

        this.currentPage = page;
        this.loadPage(page, updateHistory);
        this.updateActiveMenuItem();
        this.updateBreadcrumbs(page);
    }

    /**
     * Load a specific page
     * @param {string} page - Page to load
     * @param {boolean} updateHistory - Whether to update browser history
     */
    loadPage(page, updateHistory = true) {
        const pageConfig = this.pages[page];
        
        // Update page title
        document.title = `${pageConfig.title} - Logistics Management`;

        // Update browser history
        if (updateHistory) {
            const url = new URL(window.location);
            url.searchParams.set('page', page);
            history.pushState({ page: page }, pageConfig.title, url);
        }

        // Load page content
        this.loadPageContent(page);
        
        // Initialize page-specific functionality
        this.initializePage(page);

        // Update navigation state
        this.updateNavigationState(page);
    }

    /**
     * Load page content
     * @param {string} page - Page to load
     */
    loadPageContent(page) {
        const mainContent = document.getElementById('main-content');
        if (!mainContent) {
            console.error('Main content container not found');
            return;
        }

        // Clear existing content
        mainContent.innerHTML = '<div class="loading">Loading...</div>';

        // Load page-specific content
        switch (page) {
            case 'service-orders':
                this.loadServiceOrdersPage();
                break;
            case 'dashboard':
                this.loadDashboardPage();
                break;
            case 'operations':
                this.loadOperationsPage();
                break;
            case 'equipment':
                this.loadEquipmentPage();
                break;
            case 'inventory':
                this.loadInventoryPage();
                break;
            case 'providers':
                this.loadProvidersPage();
                break;
            case 'customers':
                this.loadCustomersPage();
                break;
            case 'reports':
                this.loadReportsPage();
                break;
            case 'settings':
                this.loadSettingsPage();
                break;
            default:
                this.load404Page();
                break;
        }
    }

    /**
     * Load service orders page
     */
    loadServiceOrdersPage() {
        // Service Orders page content is created by ServiceOrdersUI module
        if (window.ServiceOrdersUI) {
            // The ServiceOrdersUI module handles its own content creation
            console.log('Service Orders page loaded');
        } else {
            this.showModuleNotAvailable('Service Orders');
        }
    }

    /**
     * Load dashboard page
     */
    loadDashboardPage() {
        const mainContent = document.getElementById('main-content');
        mainContent.innerHTML = `
            <div class="dashboard-container">
                <div class="page-header">
                    <h1>Dashboard</h1>
                    <p class="subtitle">Overview of your logistics operations</p>
                </div>
                
                <!-- Quick Stats -->
                <div class="stats-grid">
                    <div class="stat-card">
                        <div class="stat-icon orders">📋</div>
                        <div class="stat-content">
                            <h3 id="dashTotalOrders">-</h3>
                            <p>Total Orders</p>
                            <span class="stat-change positive" id="ordersChange">+12%</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon equipment">🔧</div>
                        <div class="stat-content">
                            <h3 id="dashActiveEquipment">-</h3>
                            <p>Active Equipment</p>
                            <span class="stat-change" id="equipmentChange">85%</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon revenue">💰</div>
                        <div class="stat-content">
                            <h3 id="dashRevenue">$-</h3>
                            <p>This Month</p>
                            <span class="stat-change positive" id="revenueChange">+8%</span>
                        </div>
                    </div>
                    <div class="stat-card">
                        <div class="stat-icon efficiency">📈</div>
                        <div class="stat-content">
                            <h3 id="dashEfficiency">-%</h3>
                            <p>Efficiency</p>
                            <span class="stat-change positive" id="efficiencyChange">+5%</span>
                        </div>
                    </div>
                </div>

                <!-- Quick Actions -->
                <div class="quick-actions">
                    <h2>Quick Actions</h2>
                    <div class="action-grid">
                        <button class="action-card" data-action="create-order">
                            <i class="icon-plus">➕</i>
                            <span>New Service Order</span>
                        </button>
                        <button class="action-card" data-action="equipment-status">
                            <i class="icon-equipment">🔧</i>
                            <span>Equipment Status</span>
                        </button>
                        <button class="action-card" data-action="maintenance-schedule">
                            <i class="icon-calendar">📅</i>
                            <span>Maintenance Schedule</span>
                        </button>
                        <button class="action-card" data-action="reports">
                            <i class="icon-chart">📊</i>
                            <span>View Reports</span>
                        </button>
                    </div>
                </div>

                <!-- Recent Activity -->
                <div class="recent-activity">
                    <h2>Recent Activity</h2>
                    <div class="activity-list" id="recentActivityList">
                        <div class="loading">Loading recent activity...</div>
                    </div>
                </div>
            </div>
        `;

        // Load dashboard data
        this.loadDashboardData();
    }

    /**
     * Load dashboard data
     */
    loadDashboardData() {
        try {
            // Update stats from service orders
            if (window.ServiceOrders) {
                const stats = window.ServiceOrders.getOrdersStats();
                const totalOrdersEl = document.getElementById('dashTotalOrders');
                const revenueEl = document.getElementById('dashRevenue');
                
                if (totalOrdersEl) totalOrdersEl.textContent = stats.total || '0';
                if (revenueEl) revenueEl.textContent = `$${(stats.totalRevenue || 0).toLocaleString()}`;
            }

            // Update equipment stats
            if (window.EquipmentIntegration) {
                const equipStatus = window.EquipmentIntegration.getStatus();
                const activeEquipmentEl = document.getElementById('dashActiveEquipment');
                const efficiencyEl = document.getElementById('dashEfficiency');
                
                if (activeEquipmentEl) activeEquipmentEl.textContent = equipStatus.equipmentInUse || '0';
                
                const utilization = window.EquipmentIntegration.getEquipmentUtilization();
                if (efficiencyEl) efficiencyEl.textContent = `${utilization.utilizationRate || 0}%`;
            }

            // Load recent activity
            this.loadRecentActivity();
        } catch (error) {
            console.error('Error loading dashboard data:', error);
            if (window.NotificationSystem) {
                window.NotificationSystem.showError('Failed to load dashboard data');
            }
        }
    }

    /**
     * Load recent activity
     */
    loadRecentActivity() {
        const activityList = document.getElementById('recentActivityList');
        if (!activityList) return;

        try {
            const activities = [];

            // Get recent orders
            if (window.ServiceOrders) {
                const recentOrders = window.ServiceOrders.getOrders().slice(0, 5);
                recentOrders.forEach(order => {
                    activities.push({
                        type: 'order',
                        message: `Service order #${order.id} ${order.status}`,
                        timestamp: order.updatedAt,
                        icon: '🛠️'
                    });
                });
            }

            // Get recent equipment changes
            if (window.EquipmentIntegration) {
                // Add equipment status changes (simulated)
                activities.push({
                    type: 'equipment',
                    message: 'Equipment 10000 status updated to Ready',
                    timestamp: new Date().toISOString(),
                    icon: '🔧'
                });
            }

            // Sort by timestamp
            activities.sort((a, b) => new Date(b.timestamp) - new Date(a.timestamp));

            activityList.innerHTML = activities.length > 0 ? activities.map(activity => `
                <div class="activity-item">
                    <div class="activity-icon">
                        <i class="${activity.icon}">${activity.icon}</i>
                    </div>
                    <div class="activity-content">
                        <p class="activity-message">${activity.message}</p>
                        <span class="activity-time">${this.formatTimeAgo(activity.timestamp)}</span>
                    </div>
                </div>
            `).join('') : '<div class="no-activity">No recent activity</div>';
        } catch (error) {
            console.error('Error loading recent activity:', error);
            activityList.innerHTML = '<div class="no-activity">Failed to load recent activity</div>';
        }
    }

    /**
     * Load operations page
     */
    loadOperationsPage() {
        const mainContent = document.getElementById('main-content');
        mainContent.innerHTML = `
            <div class="operations-container">
                <div class="page-header">
                    <h1>Operations</h1>
                    <p class="subtitle">Monitor and manage operational activities</p>
                </div>
                <div class="operations-content">
                    <p>Operations module content will be loaded here.</p>
                </div>
            </div>
        `;
    }

    /**
     * Load equipment page
     */
    loadEquipmentPage() {
        const mainContent = document.getElementById('main-content');
        mainContent.innerHTML = `
            <div class="equipment-container">
                <div class="page-header">
                    <h1>Equipment</h1>
                    <p class="subtitle">Manage equipment inventory and maintenance</p>
                </div>
                <div class="equipment-content">
                    <p>Equipment module content will be loaded here.</p>
                    <div class="equipment-grid">
                        <div class="equipment-card">
                            <h3>9 5/8" Rotary hand sifter</h3>
                            <p>SKU: 10000</p>
                            <p>Status: <span class="status ready">Ready</span></p>
                            <p>Available: 8 / 20</p>
                        </div>
                        <div class="equipment-card">
                            <h3>9 5/8" Rotary hand sifter</h3>
                            <p>SKU: 20000</p>
                            <p>Status: <span class="status under-inspection">Under Inspection</span></p>
                            <p>Available: 20 / 20</p>
                        </div>
                        <div class="equipment-card">
                            <h3>9 5/8" Rotary hand sifter</h3>
                            <p>SKU: 30000</p>
                            <p>Status: <span class="status damage">Damage</span></p>
                            <p>Available: 8 / 20</p>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    /**
     * Check if required modules are loaded for a page
     * @param {string} page - Page to check
     * @returns {boolean} Are modules ready
     */
    checkModuleRequirements(page) {
        const pageConfig = this.pages[page];
        if (!pageConfig) return true;

        // For service-orders page, check if required modules are loaded
        if (page === 'service-orders') {
            return window.ServiceOrders && window.ServiceOrdersUI;
        }

        // Check main module
        if (pageConfig.module && !window[pageConfig.module]) {
            console.warn(`Module ${pageConfig.module} not loaded for page ${page}`);
            return false;
        }

        // Check submodules
        if (pageConfig.submodules) {
            for (const submodule of pageConfig.submodules) {
                if (!window[submodule]) {
                    console.warn(`Submodule ${submodule} not loaded for page ${page}`);
                    return false;
                }
            }
        }

        return true;
    }

    /**
     * Initialize page-specific functionality
     * @param {string} page - Page to initialize
     */
    initializePage(page) {
        const pageConfig = this.pages[page];
        
        // Initialize main module if available
        if (pageConfig.module && window[pageConfig.module]) {
            if (typeof window[pageConfig.module].init === 'function') {
                window[pageConfig.module].init();
            }
        }

        // Update badges and counters
        this.updateNavigationBadges();
    }

    /**
     * Update active menu item
     */
    updateActiveMenuItem() {
        // Remove active class from all nav links
        document.querySelectorAll('.nav-link').forEach(link => {
            link.classList.remove('active');
        });

        // Add active class to current page
        const activeLink = document.querySelector(`[data-page="${this.currentPage}"]`);
        if (activeLink) {
            activeLink.classList.add('active');
        }
    }

    /**
     * Update breadcrumbs
     * @param {string} currentPage - Current page
     * @param {Array} additionalCrumbs - Additional breadcrumb items
     */
    updateBreadcrumbs(currentPage, additionalCrumbs = []) {
        const breadcrumb = document.getElementById('breadcrumb');
        if (!breadcrumb) return;

        this.breadcrumbs = [
            { title: 'Home', page: 'dashboard' },
            { title: this.pages[currentPage].title, page: currentPage },
            ...additionalCrumbs
        ];

        breadcrumb.innerHTML = this.breadcrumbs.map((crumb, index) => {
            const isLast = index === this.breadcrumbs.length - 1;
            
            if (isLast) {
                return `<span class="breadcrumb-current">${crumb.title}</span>`;
            } else {
                return `<a href="#" class="breadcrumb-link" data-page="${crumb.page}">${crumb.title}</a>`;
            }
        }).join('<span class="breadcrumb-separator"> / </span>');
    }

    /**
     * Update navigation badges
     */
    updateNavigationBadges() {
        this.updateServiceOrdersBadge();
        this.updateEquipmentBadge();
    }

    /**
     * Update service orders badge
     */
    updateServiceOrdersBadge() {
        const badge = document.getElementById('serviceOrdersBadge');
        if (!badge) return;

        try {
            if (window.ServiceOrders) {
                const pendingOrders = window.ServiceOrders.getOrders({ status: 'pending' }).length;
                
                if (pendingOrders > 0) {
                    badge.textContent = pendingOrders;
                    badge.style.display = 'inline';
                } else {
                    badge.style.display = 'none';
                }
            } else {
                badge.style.display = 'none';
            }
        } catch (error) {
            console.error('Error updating service orders badge:', error);
            badge.style.display = 'none';
        }
    }

    /**
     * Update equipment badge
     */
    updateEquipmentBadge() {
        const badge = document.getElementById('equipmentBadge');
        if (!badge) return;

        try {
            if (window.EquipmentIntegration) {
                const status = window.EquipmentIntegration.getStatus();
                const issuesCount = status.equipmentNeedingMaintenance || 0;
                
                if (issuesCount > 0) {
                    badge.textContent = issuesCount;
                    badge.style.display = 'inline';
                    badge.className = 'nav-badge warning';
                } else {
                    badge.style.display = 'none';
                }
            } else {
                badge.style.display = 'none';
            }
        } catch (error) {
            console.error('Error updating equipment badge:', error);
            badge.style.display = 'none';
        }
    }

    /**
     * Update navigation state
     * @param {string} page - Current page
     */
    updateNavigationState(page) {
        // Update body class for page-specific styling
        document.body.className = document.body.className.replace(/page-\w+/g, '');
        document.body.classList.add(`page-${page}`);

        // Update navigation indicators
        this.updateNavigationBadges();

        // Update page metadata
        this.updatePageMetadata(page);
    }

    /**
     * Load initial page based on URL parameters
     */
    loadInitialPage() {
        const urlParams = new URLSearchParams(window.location.search);
        const page = urlParams.get('page') || 'dashboard';
        
        // Wait for modules to load before navigating
        this.waitForModules(() => {
            this.navigateTo(page, false);
        });
    }

    /**
     * Wait for required modules to load
     * @param {Function} callback - Callback to execute when ready
     */
    waitForModules(callback) {
        const checkModules = () => {
            const requiredModules = ['NotificationSystem'];
            const requiredLoaded = requiredModules.every(module => window[module]);
            
            if (requiredLoaded) {
                callback();
            } else {
                setTimeout(checkModules, 100);
            }
        };

        checkModules();
    }

    /**
     * Initialize all available modules
     */
    initializeModules() {
        try {
            // Initialize notification system first
            if (window.NotificationSystem && typeof window.NotificationSystem.init === 'function') {
                window.NotificationSystem.init();
            }

            // Initialize service orders system
            if (window.ServiceOrders && typeof window.ServiceOrders.init === 'function') {
                window.ServiceOrders.init();
            }

            // Initialize equipment integration
            if (